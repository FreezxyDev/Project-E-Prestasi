"""
DRF authentication class custom, cocok sama model Users (bukan AbstractUser).
Setiap request, status_akun & auth_key dicek ULANG ke database (bukan cuma pas
login) -- jadi kalau admin nonaktifkan akun atau reset auth_key, token yang
lagi beredar langsung gak valid lagi meski belum expired.
"""
import jwt
from rest_framework import authentication, exceptions

from .models import Users
from .jwt_utils import decode_token


class JWTAuthentication(authentication.BaseAuthentication):
    keyword = 'Bearer'

    def authenticate(self, request):
        header = authentication.get_authorization_header(request).decode('utf-8')
        if not header or not header.startswith(f'{self.keyword} '):
            return None  # gak ada token -> biar permission class yang tolak kalau endpoint butuh login

        token = header[len(self.keyword) + 1:]

        try:
            payload = decode_token(token)
        except jwt.ExpiredSignatureError:
            raise exceptions.AuthenticationFailed('Token sudah kedaluwarsa, silakan login ulang.')
        except jwt.PyJWTError:
            raise exceptions.AuthenticationFailed('Token tidak valid.')

        if payload.get('type') != 'access':
            raise exceptions.AuthenticationFailed('Token ini bukan access token.')

        try:
            user = Users.objects.get(pk=payload['user_id'])
        except Users.DoesNotExist:
            raise exceptions.AuthenticationFailed('Akun tidak ditemukan.')

        # -- bagian kill-switch --
        if user.status_akun != 'aktif':
            raise exceptions.AuthenticationFailed('Akun ini sudah dinonaktifkan.')
        if str(user.auth_key) != payload.get('auth_key'):
            raise exceptions.AuthenticationFailed('Sesi ini sudah tidak berlaku, silakan login ulang.')

        return (user, token)
